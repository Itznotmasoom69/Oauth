module.exports = {
  token: process.env.token,
  port: "3000",
  prefix: "",
  client: "",
  client_id: "1205125604844769310",
  client_secret: "0CmGlszatnpmiUoldE9lD-BMBpZXH4Zi",
  redirect_uri: "https://c8c1fed9-b49f-4ee2-8360-971444653626-00-18i6kbfem165v.janeway.replit.dev/",
  footer: "",
  support: "https://discord.com",
  wehbook: "https://discord.com/api/v10/webhooks/1206135212845834302/THGmdSPitTeCOXxz2XhmZfrtPyPkoNn6nuJHL8z0A-_tMqh-x0Z2-s6kae-OiuavwuxI", 
  owners: ["1053886661873901578","827146821968330802"],
  authLink: `https://discord.com/api/oauth2/authorize?client_id=1205125604844769310&response_type=code&redirect_uri=https%3A%2F%2Fc8c1fed9-b49f-4ee2-8360-971444653626-00-18i6kbfem165v.janeway.replit.dev%2F&scope=identify+guilds.join`,

  bn:["https://media.discordapp.net/attachments/1158752755461128262/1206837119352307772/20240213_110913_0000.png?ex=65dd75a7&is=65cb00a7&hm=de18377388e2b42b11b324875cef37ec2cdac75e6b2c0bea574631c482e47a39&"],
}
